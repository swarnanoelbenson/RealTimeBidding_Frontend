SETTING UP OF RTB PUBLISHER-ADVERTISER WEBSITE

1.	Install Xampp software
2.	Download the Git repository
3.	Unzip rtb.zip
4.	Copy rtb folder and paste it in Drive C: -> Xampp -> htdocs
5.	Now, open Xampp
6.	Click on start of first two modules (Apache and MySQL)
7.	Click on Admin of MySQL
8.	Click on Import and import the real_time_bidding.sql file
9.	Open a new tab and in the URL, type localhost/rtb/main_page.php
