-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 23, 2024 at 02:39 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `real_time_bidding`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertisers`
--

CREATE TABLE `advertisers` (
  `advertiser_id` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `advertiser_name` varchar(255) NOT NULL,
  `image1` blob DEFAULT NULL,
  `image2` blob DEFAULT NULL,
  `image3` blob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `advertisers`
--

INSERT INTO `advertisers` (`advertiser_id`, `password`, `advertiser_name`, `image1`, `image2`, `image3`) VALUES
('Advertiser1', '$2y$10$gRjmk88wszayQF7U4yP9qO7WQvmRDCPO2SENbuPjLWZQJG9w0JxHy', 'Advertiser1', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `auctions`
--

CREATE TABLE `auctions` (
  `auction_id` int(11) NOT NULL,
  `auction_name` varchar(255) NOT NULL,
  `last_date_for_bid` date NOT NULL,
  `bid_starting_price` decimal(10,2) UNSIGNED NOT NULL,
  `publisher_id` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auctions`
--

INSERT INTO `auctions` (`auction_id`, `auction_name`, `last_date_for_bid`, `bid_starting_price`, `publisher_id`) VALUES
(12, 'Auction1', '0000-00-00', '100.00', 'Publisher1');

-- --------------------------------------------------------

--
-- Table structure for table `publishers`
--

CREATE TABLE `publishers` (
  `publisher_id` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `publisher_name` varchar(255) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `publisher_logo` longblob DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `publishers`
--

INSERT INTO `publishers` (`publisher_id`, `password`, `publisher_name`, `domain`, `publisher_logo`) VALUES
('1234', '$2y$10$JvqMSPEjIqPomf3hZEEG9OT9Wa1xco36lqlNdEmA2BeIOt46QRUry', '1234', '1234', 0x4c6f676f2e6a7067),
('A', '$2y$10$.5af.huBLWWX/VFd/NDkJ.9bjwYkO8h0.tcl/zerQNrOiwqkZgodK', 'a', 'a', 0x4c6f676f2e6a7067),
('Aruna', '$2y$10$BY66AjF8741o37RvJI8KDeYj/gUHQiAEpk5fmQJ9VLa.Hcs0gPe9C', 'Aruna', 'Aruna.com', 0x4c6f676f2e6a7067),
('asa', '$2y$10$R4e9I1fNgHvDFWHK1LQdQuHEFwAPqSTOLzxvFKZRuZd5h.n.Y/3cS', 'asa', 'asa', 0x4c6f676f2e6a7067),
('Preethi', '$2y$10$Hz9mGdPzqlq.SjWrTyO8GOVoBoG55LYwwKVYQQhYygQN17IwM6ceu', 'Preethi', 'Preethi.com', 0x53637265656e73686f7420323032342d30352d3330203132343830332e6a7067),
('Publisher1', '$2y$10$IqqNU2/lPnuoelI7vGGC9.p3bslYfHerLPjjXOZWF1IO56GvedVGi', 'Publisher1', 'Publisher1.com', 0x53637265656e73686f7420323032342d30362d3138203233323031362e6a7067),
('qwq', '$2y$10$1zG.67EusaTw0MCA.32tg.g9NfMTcZwpYgzhPltDB37exKjwj4Yyi', 'qwq', 'qwq', 0x4c6f676f2e6a7067),
('Rr', '$2y$10$XyxjXJEoqDWskt2FKjpQ2u/f8v9gvRiDX4H3tiWHwaPzfFnlNIbm2', 'rr', 'rr', 0x5061796d656e742070726f6f662e706e67),
('Thomas', '$2y$10$1Tr419NWKD6hcbAfh6e6Zem9z9hRzNCwiN0qlRSCJLYZ/Aw9wU5nu', 'Thomas', 'Thomas', 0x4c6f676f2e6a7067),
('xcx', '$2y$10$WvL2t4T2Fmf3ull4BrUXU.huHM924/XXUPV2XOm1t1lwhfWdWzSQm', 'xcx', 'xcx', 0x4c6f676f2e6a7067),
('Zz', '$2y$10$7A0WJ0n69bJBLaUV8HCLOebZimh0jDPYdwX/c/T8eHl.xN9kP8voC', 'zz', 'zz', 0x4c6f676f2e6a7067);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertisers`
--
ALTER TABLE `advertisers`
  ADD PRIMARY KEY (`advertiser_id`);

--
-- Indexes for table `auctions`
--
ALTER TABLE `auctions`
  ADD PRIMARY KEY (`auction_id`),
  ADD KEY `Publisher_id` (`publisher_id`);

--
-- Indexes for table `publishers`
--
ALTER TABLE `publishers`
  ADD PRIMARY KEY (`publisher_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auctions`
--
ALTER TABLE `auctions`
  MODIFY `auction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auctions`
--
ALTER TABLE `auctions`
  ADD CONSTRAINT `Publisher_id` FOREIGN KEY (`publisher_id`) REFERENCES `publishers` (`publisher_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
